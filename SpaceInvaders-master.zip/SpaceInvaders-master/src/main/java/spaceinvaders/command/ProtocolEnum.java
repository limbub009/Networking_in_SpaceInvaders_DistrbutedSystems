package spaceinvaders.command;

/** The protocols over which a command can be sent. */
public enum ProtocolEnum {
  TCP,
  UDP
}
