package spaceinvaders.game;

/** Types of entities. */
public enum EntityEnum {
  INVADER,
  PLAYER,
  INVADER_BULLET,
  PLAYER_BULLET,
  SHIELD;
}
