java -jar space-invaders-1.0.0-jar-with-dependencies.jar server 5412
