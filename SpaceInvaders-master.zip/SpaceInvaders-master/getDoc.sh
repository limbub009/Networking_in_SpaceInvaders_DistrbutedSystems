javadoc -d doc -sourcepath src/main/java -subpackages spaceinvaders -exclude com.google.gson
